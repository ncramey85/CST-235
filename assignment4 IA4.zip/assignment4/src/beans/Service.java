package beans;

import javax.inject.Inject;

import business.AnotherOrdersBusinessService;
import business.OrdersBusinessInterface;
import business.OrdersBusinessService;

/*public class Service implements OrdersBusinessInterface {
	public Service() {
		// TODO Auto-generated constructor stub
	}
	//@Inject
	public void test() {
		// TODO Auto-generated method stub
		OrdersBusinessService service = null;
		AnotherOrdersBusinessService another = null;
		service.test();
		another.test();
	}
}*/
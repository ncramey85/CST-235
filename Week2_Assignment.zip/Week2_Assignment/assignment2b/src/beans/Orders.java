package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class Orders {
	List <Order> orders = new ArrayList<Order>();
	
	public Orders(){
		orders.add(new Order("0", "Sheba", (float)1.00, 1));
		orders.add(new Order("1", "Butch", (float)1.10, 1));
		orders.add(new Order("2", "Smokey", (float)0.90, 1));
		orders.add(new Order("3", "Freakshow Rabbit", (float)11.00, 1));
		orders.add(new Order("4", "Bonnie", (float)10.00, 1));
		orders.add(new Order("5", "Phil", (float)20.00, 1));
		
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
}

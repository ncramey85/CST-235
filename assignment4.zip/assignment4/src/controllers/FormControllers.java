package controllers;

import javax.faces.bean.*;
import javax.faces.context.FacesContext;
import javax.inject.*;
import beans.User;
import business.OrdersBusinessInterface;

import java.sql.*;

import javax.ejb.EJB;

@ManagedBean 
@ViewScoped
public class FormControllers {
	@Inject
	private business.OrdersBusinessInterface service;
	@EJB 
	business.MyTimerService timer;
	
	public String onSubmit(User user) {		
		service.test(); 
		timer.setTimer(10000); 
		getAllOrders();
		insertOrder();
		getAllOrders();
		return "TestResponse.xhtml"; 
	}
	public String onFlash(User user){
		System.out.println(FacesContext.getCurrentInstance().getClientIdsWithMessages());
		getRequestMap();
		return "TestResponse.xhtml?faces-redirect=true";
	}
	public String getRequestMap() {
		return "TestResponse.xhtml";
	}
	public  OrdersBusinessInterface getService() {
		return service;
	}
	
	private void getAllOrders(){
		Connection connection = null;
		String url = "jdbc:postgresql://localhost:5432/";
		String username = "sade";
		String password = "sade";
		String stringStatement = "SELECT * FROM testapp.ORDERS";
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Success");
			Statement statement  = connection.createStatement();
			ResultSet rs = statement.executeQuery(stringStatement);
			while(rs.next()) {
				System.out.println("ID:"+ rs.getInt("ID")+"; Product:"+rs.getString("PRODUCT_NAME")+"; Price:"+ rs.getFloat("PRICE")
				+ "; QUANT:"+rs.getString("QUANTITY"));
			}
			rs.close();
			connection.close();
		} catch (SQLException e) {
			System.out.println("Failure");
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	private void insertOrder() {
		Connection connection = null;
		String url = "jdbc:postgresql://localhost:5432/";
		String username = "sade";
		String password = "sade";
		String stringStatement = "INSERT INTO  testapp.ORDERS(ORDER_NO, PRODUCT_NAME, PRICE, QUANTITY) VALUES('001122334455', 'This was inserted new', 25.00, 100)";
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Success");
			Statement statement  = connection.createStatement();
			statement.executeUpdate(stringStatement);

			connection.close();
		} catch (SQLException e) {
			System.out.println("Failure");
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}


package beans;
import javax.faces.bean.*;
import javax.validation.constraints.*;


@ManagedBean 
@ViewScoped
public class User {
	
	@NotNull()
	@Size(min=5, max=15) 
	String firstName;
	
	@NotNull()
	@Size(min=5, max=15)
	String lastName;

	public User(String FirstName, String LastName) { 
		firstName = FirstName;
		lastName = LastName;
	}
	
	public User() { 
		firstName = "Nate";
		lastName = "Ramey";
	}
	
	//Setters/Getters FirstName
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String FirstName) {
		firstName = FirstName;
	}
	
	//Setters/Getters LastName
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String LastName) {
		lastName = LastName;
	}
}
package beans;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.faces.bean.*;

@ManagedBean(name="orders", eager = true) 
@ViewScoped


public class Orders implements Serializable {
	   private static final long serialVersionUID = 1L;
		String orderNumber;
		String productName;
		float price;
		int quantity;
		
		///List of Temp Data
	   private static final ArrayList <Order> orders = new ArrayList <Order>(Arrays.asList(new Order("MODELS","TEST",44,1),
			   new Order("PDE","TEST",44,2),new Order("CFG","TEST",44,3),new Order("SELF-TEST","TEST",44,4)));

 
	//Getters/Setters
	public List <Order> getOrders() {
		return orders;
	}
	public void setOrderNumber(Order OrderObj) {
		orders.add(OrderObj);
	}
	
}
package database;

import java.util.List;

import beans.Bible;

public interface BDInterface {
	// Interface for methods to access Bible 
	public List <Bible> getBible();
}

package database;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.Bible;

@Stateless
@Local(BDInterface.class)
@LocalBean
public class BDService implements BDInterface {
	// EJB for bible data
	String bookName = "";

	// Import bible.txt file
	@Override
	public List <Bible> getBible() {
		List <Bible> bibleBooks = new ArrayList <Bible>();
		String str;
		
		// Integer for chapter numbers
		int chapter = 0;
		int verse = 0;

		try {
			InputStream inputStream = getClass().getClassLoader().getResourceAsStream("bible.txt");
			BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
			while ((str = in.readLine()) != null) {
				if (!Character.isDigit(str.charAt(0))) {
					bookName = str;
				} else {
					chapter = Integer.parseInt(str.substring(0, str.indexOf(":")));
					int index = str.indexOf(":");
					int index2 = str.indexOf(":", str.indexOf(":") + 1);
					
					// Verse Number
					verse = Integer.parseInt(str.substring(index + 1, index2));
					bibleBooks.add(new Bible(bookName, chapter, verse, str.substring(str.indexOf(" ") + 1)));
				}
			}
			in.close();
			inputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//Returns as a list
		return bibleBooks;
	}
}

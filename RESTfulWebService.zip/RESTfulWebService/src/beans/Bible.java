package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.xml.bind.annotation.XmlRootElement;

@ManagedBean
@ViewScoped
@XmlRootElement(name = "bible")
public class Bible {

	private String bookName="";
	private int chapter = 0;
	private int verse = 0;
	private String scripture="";

	// Constructor
	public Bible() {
	}

	// Loaded Constructor
	public Bible(String bookName, int chapter, int verse, String words) {
		this.bookName = bookName;
		this.chapter = chapter;
		this.verse = verse;
		this.scripture = words;
	}

	// Getters & Setters
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getChapter() {
		return chapter;
	}
	public void setChapter(int chapter) {
		this.chapter = chapter;
	}
	public int getVerse() {
		return verse;
	}
	public void setVerse(int verse) {
		this.verse = verse;
	}
	public String getScripture() {
		return scripture;
	}
	public void setScripture(String scripture) {
		this.scripture = scripture;
	}
}

package business;

import beans.Bible;

public interface BBInterface {

	public int wordOccurrence(String searchString);
	public Bible firstOccurence(String searchString);
	public Bible bookChapterVerse(String bookName, int chapter, int verse);
}

package business;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import beans.Bible;
import database.BDInterface;

@Stateless
@Local(BBInterface.class)
@LocalBean
public class BBService implements BBInterface {

	// Variable to hold the name of a bible book
	String bookName = "";
	// Boolean for true and false searches
	boolean foundWord;
	// Integer for word count 
	int wordCount = 0;
	
	Bible bibleScripture = new Bible();
	@Inject
	BDInterface service;

	@Override
	public int wordOccurrence(String searchString) {
		List <Bible> bibleBooks = service.getBible();
		// Word Count set to zero
		wordCount = 0;
		bibleBooks.forEach(x -> {
			if (x.getScripture().toLowerCase().contains(searchString.toLowerCase())) {
				wordCount = wordCount + 1;
			}
		});
		return wordCount;
	}

	@Override
	public Bible firstOccurence(String searchString) {

		bibleScripture = new Bible();
		List <Bible> bibleBooks = service.getBible();
		int i = 0;
		// Reset boolean 
		foundWord = false;
		while (!foundWord) {
			if (bibleBooks.get(i).getScripture().toLowerCase().contains(searchString.toLowerCase())) {
				foundWord = true;
				bibleScripture = bibleBooks.get(i);
			} else {
				i++;
			}
		}
		return bibleScripture;
	}
	@Override
	public Bible bookChapterVerse(String bookName, int chapter, int verse) {
		
		// Bible Scripture set back to null
		bibleScripture = new Bible();
		List <Bible> bibleBooks = service.getBible();

		bibleBooks.forEach(x -> {
			if (x.getBookName().toLowerCase().equals(bookName.toLowerCase()) && x.getChapter() == chapter
					&& x.getVerse() == verse) {
				bibleScripture = x;
			}
		});
		return bibleScripture;
	}

}
